var jwt = require('jsonwebtoken');
var bcrypt = require('bcrypt');
require('dotenv').config();

var JWT_SECRET = process.env.JWT_SECRET || 'your_secret_key';

// Hash password
var hashPassword = async function(password) {
    var salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(password, salt);
};

// Compare password
var comparePassword = async function(password, hashedPassword) {
    return await bcrypt.compare(password, hashedPassword);
};

// Generate JWT
var generateToken = function(user) {
    return jwt.sign(
        { id: user.id, email: user.email, role: 'student' },
        JWT_SECRET,
        { expiresIn: '1d' }
    );
};

// Verify JWT
var verifyToken = function(token) {
    return jwt.verify(token, JWT_SECRET);
};

module.exports = {
    hashPassword,
    comparePassword,
    generateToken,
    verifyToken
};